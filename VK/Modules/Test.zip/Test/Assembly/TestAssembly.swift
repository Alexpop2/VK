//
//  TestTestAssembly.swift
//  VK
//
//  Created by Alexey Poponin on 09/02/2019.
//  Copyright © 2019 Aleksei Poponin. All rights reserved.
//

import UIKit

class TestAssembly {
    func build() -> (controller: UIViewController, presenter: TestPresenter)? {
        let storyboard = UIStoryboard(name: "TestStoryboard", bundle: nil)
        let rootVC = storyboard.instantiateViewController(withIdentifier: "TestViewControllerIdentifier")
        guard let moduleVC = rootVC as? TestViewController else {
            return nil
        }
        
        let presenter = TestPresenter()
        let interactor = TestInteractor()
        
        moduleVC.output = presenter
        presenter.interactor = interactor
        presenter.view = moduleVC
        interactor.output = presenter
        
        return(controller: moduleVC, presenter: presenter)
    }
}
