//
//  TestTestViewController.swift
//  VK
//
//  Created by Alexey Poponin on 09/02/2019.
//  Copyright © 2019 Aleksei Poponin. All rights reserved.
//

import UIKit

class TestViewController: UIViewController {

    private var viewOutput: TestViewOutput!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

}

extension TestViewController: TestViewInput {
    var output: TestViewOutput {
        get {
            return viewOutput
        }
        set {
            viewOutput = newValue
        }
    }
}
