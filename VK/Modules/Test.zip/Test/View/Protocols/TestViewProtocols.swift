//
//  TestTestViewProtocols.swift
//  VK
//
//  Created by Alexey Poponin on 09/02/2019.
//  Copyright © 2019 Aleksei Poponin. All rights reserved.
//

import Foundation

protocol TestViewInput: class {
    var output: TestViewOutput { get set }
}

protocol TestViewOutput: class {
	
}