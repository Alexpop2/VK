//
//  TestTestPresenter.swift
//  VK
//
//  Created by Alexey Poponin on 09/02/2019.
//  Copyright © 2019 Aleksei Poponin. All rights reserved.
//

import Foundation

class TestPresenter {
    private weak var presenterDelegate: TestPresenterDelegate!
    private weak var moduleView: TestViewInput!
    private var moduleInteractor: TestInteractorInput!
}

extension TestPresenter: TestPresenterInput {
    var delegate: TestPresenterDelegate {
        get {
            return presenterDelegate
        }
        set {
            presenterDelegate = newValue
        }
    }
    
    var view: TestViewInput {
        get {
            return moduleView
        }
        set {
            moduleView = newValue
        }
    }
    
    var interactor: TestInteractorInput {
        get {
            return moduleInteractor
        }
        set {
            moduleInteractor = newValue
        }
    }
    
    
}

extension TestPresenter: TestInteractorOutput {

}

extension TestPresenter: TestViewOutput {

}
