//
//  TestTestPresenterProtocols.swift
//  VK
//
//  Created by Alexey Poponin on 09/02/2019.
//  Copyright © 2019 Aleksei Poponin. All rights reserved.
//

import Foundation

protocol TestPresenterInput: class {
    var delegate: TestPresenterDelegate { get set }
    var view: TestViewInput { get set }
    var interactor: TestInteractorInput { get set }
}

protocol TestPresenterDelegate: class {
}
