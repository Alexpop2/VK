//
//  TestTestInteractorProtocols.swift
//  VK
//
//  Created by Alexey Poponin on 09/02/2019.
//  Copyright © 2019 Aleksei Poponin. All rights reserved.
//

import Foundation

protocol TestInteractorInput: class {
    var output: TestInteractorOutput { get set }
}

protocol TestInteractorOutput: class {
}
